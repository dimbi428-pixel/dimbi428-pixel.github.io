﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

/********  класс Провайдер погоды  ********/
/******				v1.4			*******/
/******		2025 © leXxiR [4pda]	*******/

	class WeatherProvider {
	  constructor(props = {}) {
		this.props = {
			night_icons: [],											// индексы иконок для замены день-ночь
			index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,		// текущий индекс провайдера (сохраняется и считывается из памяти)
			show_toast: true,											// показывать всплывающее сообщение при переключении провайдера
			temp_widget: null,											// виджет TEXT для отображения температуры
			temp_max_widget: null,										// виджет TEXT для отображения максимальной температуры
			temp_min_widget: null,										// виджет TEXT для отображения минимальной температуры
			temp_feels_widget: null,									// виджет TEXT для отображения ощущаемой температуры
			description_widget: null,									// виджет TEXT для отображения текстового описания текущей погоды
			cityName_widget: null,										// виджет TEXT для отображения названия города
			icon_widget: null,											// виджет IMG для отображения значка погоды
			time_sensor: null,											// сенсор времени, если не задан, то создается новый
			weather_sensor: null,										// сенсор погоды, если не задан, то создается новый
			file_name: 'weather.json',									// имя файла с погодными данными
			auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять weatherProvider.update() в event.MINUTEEND и WIDGET_DELEGATE)
			lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
			...props,
		};

		this.providers = [
						{name: ['Zepp', 'Zepp'], appId: null},							// 0
						{name: ['Погодный сервис', 'Weather service'], appId: 1065824},	// 1
						{name: ['RuWeather', 'RWeather'], appId: 1066654},				// 2
					]

		this.description = [
				['Облачно', 'Временами дождь', 'Временами снег', 'Ясно', 'Пасмурно', 'Слабый дождь', 'Слабый снег', 'Умеренный дождь', 'Умеренный снег', 'Сильный снегопад', 'Сильный дождь', 'Песчаная буря', 'Мокрый снег', 'Туман', 'Дымка', 'Дождь с грозой', 'Метель', 'Пыльно', 'Ливень', 'Дождь с градом', 'Сильный дождь с градом', 'Сильный дождь', 'Пыльная буря', 'Сильная песчаная буря', 'Сильный дождь', 'Обновите погоду', 'Облачно ночью', 'Дождливо ночью', 'Ясно ночью'],
				['Cloudy', 'Showers', 'Snow Showers', 'Sunny', 'Overcast', 'Light Rain', 'Light Snow', 'Moderate Rain', 'Moderate Snow', 'Heavy Snow', 'Heavy Rain', 'Sandstorm', 'Rain and Snow', 'Fog', 'Hazy', 'T-Storms', 'Snowstorm', 'Floating dust', 'Very Heavy Rainstorm', 'Rain and Hail', 'T-Storms and Hail', 'Heavy Rainstorm', 'Dust', 'Heavy sand storm', 'Rainstorm', 'Unknown', 'Cloudy Nighttime', 'Showers Nighttime', 'Sunny Nighttime'],
			]

		this.last = {
			weatherIcon: 25,
			weatherDescription:  'Нет данных',
			temperature: '--',
			temperatureFeels: '--',
			temperatureMax: '--',
			temperatureMin: '--',
			cityName: '--',
			modTime: null,
		}

		if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
		if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
		if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
		if (this.props.auto_update) this.createHandlers();
	  }

	// создание обработчиков автоматического обновления погоды
		createHandlers() {
			this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

			this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			  resume_call: ( () => this.update() )
			})
		}

	// служебные функции
		arrayBufferToCyrillic(buffer) {
		  let result = '';
		  const bytes = new Uint8Array(buffer);

		  let i = 0;
		  while (i < bytes.length) {
			let byte1 = bytes[i++];
			
			if (byte1 < 0x80) {								// Обработка 1-байтовых символов (ASCII)
			  result += String.fromCharCode(byte1);
			} else if (byte1 >= 0xC0 && byte1 < 0xE0) {		// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
			  let byte2 = bytes[i++];
			  let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
			  result += String.fromCharCode(charCode);
			} else if (byte1 >= 0xE0 && byte1 < 0xF0) {		// Обработка 3-байтовых символов (например, для UTF-8)
			  let byte2 = bytes[i++];
			  let byte3 = bytes[i++];
			  let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
			  result += String.fromCharCode(charCode);
			}
		  }

		  return result
		}

	// чтение погодных данных из файла
		readFile(app_id) {
		  if (!app_id) return null				
		  let str_result = "";
		  try {
			const [fs_stat, err] = hmFS.stat(this.props.file_name, {
			  appid: app_id,
			});
			if (err == 0) {
			  const fh = hmFS.open(this.props.file_name, hmFS.O_RDONLY, {
				appid: app_id,
			  });

			  const len = fs_stat.size;
			  let array_buffer = new ArrayBuffer(len);
			  hmFS.read(fh, array_buffer, 0, len);
			  hmFS.close(fh);
			  str_result = this.arrayBufferToCyrillic(array_buffer);

			  return str_result;
			} else {
			  console.log("err:", err);
			}
		  } catch (error) {
			console.log("error:", error);
			console.log("FAIL: No access to hmFS.");
		  }
		  return null;
		}

	// получить время последнего изменеия файла
		getFileModTime(app_id) {
		  if (!app_id) return null
		  try {
			const [fs_stat, err] = hmFS.stat(this.props.file_name, {
			  appid: app_id,
			});
			
			if (err == 0) {
			  return fs_stat.mtime
			} else {
			  console.log("ModTime err:", err);
			}
		  } catch (error) {
			console.log("ModTime error:", error);
			console.log("FAIL: No access to hmFS.");
		  }
			return null
		}

	// проверка времени суток: возвращает true, если сейчас день
		isDayNow() {
			const sunData = this.props.weather_sensor.getForecastWeather().tideData;
			let sunriseMins = 8 * 60;			// время восхода
			let sunsetMins = 20 * 60;			// и заката по умолчанию

			if (sunData.count > 0){
				const today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			}

			const curMins = curTime.hour * 60 + curTime.minute;
			const nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

			return nowIsDay
		}


	// сопоставление индекса иконки погоды из приложений WeatherService и RuWeather с иконками погоды от Zepp 
		getZeppIconIndex(index, app_id = null) {
			
			if (!app_id)  return index;			//	если нет app_id, то не меняем индекс иконки

			let newIndex = 25;
			
			if (app_id == 1065824) {					// WeatherService
				switch(index) {
				   case 1:
						newIndex = 3;
					break;
				   case 2:
						newIndex = 0;
					break;
				   case 3:
				   case 4:
						newIndex = 4;
					break;
				   case 5:
						newIndex = 1;
					break;
				   case 6:
						newIndex = 5;
					break;
				   case 7:
						newIndex = 10;
					break;
				   case 8:
						newIndex = 15;
					break;
				   case 9:
						newIndex = 6;
					break;
				   case 10:
						newIndex = 8;
					break;
				   case 11:
						newIndex = 9;
					break;
				   case 12:
						newIndex = 12;
					break;
				   case 13:
						newIndex = 13;
					break;
				   case 14:
						newIndex = 17;
					break;
				   default:
						newIndex = 25;
					break;
				}
			} else if (app_id == 1066654) {					// RuWeather
				newIndex = index - 1;
			}

			return newIndex
		}

	// температура со знаком
		tempWithSign(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
			val = Math.round(val);
			if (val > 0) val = '+' + val;
			val += '°';
			
			return val
		}

	//получение погодных данных из Zepp
		getZeppWeatherData() {
			const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
			const data = {
				weatherIcon: iconIndex,
				weatherDescription:  this.description[this.props.lang][iconIndex],
				temperature: this.props.weather_sensor.current ?? '--',
				temperatureFeels: '--',
				temperatureMax: this.props.weather_sensor.high ?? '--',
				temperatureMin: this.props.weather_sensor.low ?? '--',
				cityName: this.props.weather_sensor.getForecastWeather().cityName ?? '--',
			}

			return data
		}

	//получение погодных данных из файла приложения
		getAppWeatherData(app_id) {
			const data = {
				weatherIcon: 25,
				weatherDescription:  'Нет данных',
				temperature: '--',
				temperatureFeels: '--',
				temperatureMax: '--',
				temperatureMin: '--',
				cityName: '--',
			}

			// читаем данные из файла данных приложения
			let weather_str = this.readFile(app_id);
			let weatherJson = JSON.parse(weather_str);
	  
			if (weatherJson) {
				if (isFinite(weatherJson.weatherIcon)) {		// считываем индекс иконки погоды и сразу переводим в нумерацию Zepp
				  data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
				}

				if (weatherJson?.weatherDescriptionExtended?.length) {
				  data.weatherDescription = weatherJson.weatherDescriptionExtended;
				  data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());
				} else data.weatherDescription = this.description[data.weatherIcon];

				if (isFinite(weatherJson.temperature)) {
				  data.temperature = parseFloat(weatherJson.temperature);
				  data.temperature = Math.round(data.temperature);
				}
				
				if (isFinite(weatherJson.temperatureFeels)){
					data.temperatureFeels = parseFloat(weatherJson.temperatureFeels);
					data.temperatureFeels = Math.round(data.temperatureFeels);
				}
				  
				if (isFinite(weatherJson.temperatureMax)){
					data.temperatureMax = parseFloat(weatherJson.temperatureMax);
					data.temperatureMax = Math.round(data.temperatureMax);
				}
				  
				if (isFinite(weatherJson.temperatureMin)){
					data.temperatureMin = parseFloat(weatherJson.temperatureMin);
					data.temperatureMin = Math.round(data.temperatureMin);
				}
				
				if (weatherJson.city) {
				  data.cityName = weatherJson.city;
				}
			}
			
			return data
		}

	//получение погодных данных из файла приложения или Zepp
		getWeatherData(app_id = null) {
			if (!app_id) return this.getZeppWeatherData()		// если нет app_id, то получаем данные от Zepp
			else return this.getAppWeatherData(app_id);			// иначе читаем данные из файла данных приложения
		}

	// обновить виджеты, используя данные текущего провайдера
		update() {
			let curIcon = parseInt(this.last.weatherIcon);				// текущий индекс значка погоды без учета времени суток (т.е. число без "n")

			const modTime = this.getFileModTime(this.providers[this.props.index].appId);		// время изменеия файла с данными
			
			if (!modTime || this.last.modTime != modTime){										// если не получено время изменеия или оно отличается от последнего времени изменеия
				const newData = this.getWeatherData(this.providers[this.props.index].appId);	// тогда читаем новые данные из файла
				this.last.modTime = modTime;

				let val = this.tempWithSign(newData.temperature);
				if (val != this.last.temperature){
					this.last.temperature = val;
					if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign(newData.temperatureMax);
				if (val != this.last.temperatureMax){
					this.last.temperatureMax = val;
					if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign(newData.temperatureMin);
				if (val != this.last.temperatureMin){
					this.last.temperatureMin = val;
					if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign(newData.temperatureFeels);
				if (val != this.last.temperatureFeels){
					this.last.temperatureFeels = val;
					if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = newData.cityName;
				if (val != this.last.cityName){
					this.last.cityName = val;
					if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = newData.weatherDescription;
				if (val != this.last.weatherDescription){
					this.last.weatherDescription = val;
					if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, val);
				}

				
				curIcon = newData.weatherIcon;						// получаем текущий индекс значка погоды
			}

			if (this.props.night_icons.includes(curIcon) && !this.isDayNow()){		// если он в списке ночных иконок и сейчас "ночь", то добавляем суффикс 'n'
				curIcon += 'n';
			}

			if (curIcon != this.last.weatherIcon){
				this.last.weatherIcon = curIcon;
				if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, `w_${curIcon}.png`);
			}
		}

	// переключить на следующего провайдера
		next(show_toast = this.props.show_toast) {
			const v = (this.props.index + 1) % this.providers.length;
			this.provider = v;
			if (show_toast) hmUI.showToast({text: this.name});
		}

	// переключить на предыдующего провайдера
		prev(show_toast = this.props.show_toast) {
			const v = (this.props.index - 1 + this.providers.length) % this.providers.length;
			this.provider = v;
			if (show_toast) hmUI.showToast({text: this.name});
		}

	// переключить назад или вперед
		toggle(dir, show_toast = this.props.show_toast) {
			if (dir > 0) this.next(show_toast)
			else this.prev(show_toast);
		}
		
	// установить провайдера по индексу
		set provider(v) {
			this.props.index = v;
			hmFS.SysProSetInt('WeatherProviderIndex', v);
			this.update();
		}

	// получить индекс текущего провайдера
		get index() {
			return this.props.index
		}

	// получить название текущего провайдера
		get name() {
			return this.providers[this.props.index].name[this.props.lang]
		}

	// получить название города
		get cityName() {
			return this.last.cityName
		}

	// получить текущую температуру
		get temperature() {
			return this.last.temperature
		}

	// получить максимальную температуру
		get temperatureMax() {
			return this.last.temperatureMax
		}

	// получить минимальную температуру
		get temperatureMin() {
			return this.last.temperatureMin
		}

	// получить ощущаемую температуру
		get temperatureFeels() {
			return this.last.temperatureFeels
		}

	// получить описание погоды
		get weatherDescription() {
			return this.last.weatherDescription
		}

	// удалить
	  delete() {
		this.providers = null;
		this.props = null;
		this.last = null;
		this.description = null;
		if (this.widgetDelegate) {
			hmUI.deleteWidget(this.widgetDelegate);
			this.widgetDelegate = null;
		}
	  }

	}
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_battery_current_text_font = ''
        let idle_battery_image_progress_img_level = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let idle_day_month_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_heart_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_walking_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['Fon.png', 'C_0.png', 'C_1.png', 'C_2.png', 'C_3.png', 'C_4.png', 'C_5.png', 'C_6.png'];
        let backgroundToastList = ['Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'Fon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 14,
              y: 269,
              w: 70,
              h: 30,
              text_size: 25,
              char_space: 0,
              color: 0xFFFF8000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 306,
              y: 269,
              w: 70,
              h: 30,
              text_size: 25,
              char_space: 0,
              color: 0xFFFF8000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 276,
              y: 60,
              src: 'Blok_on.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 308,
              y: 61,
              src: 'NeBes_on.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 8,
              y: 60,
              src: 'BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 344,
              y: 61,
              src: 'Bud_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 242,
              y: 390,
              w: 116,
              h: 50,
              text_size: 40,
              char_space: 0,
              color: 0xFF00BB00,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 21,
              y: 390,
              w: 130,
              h: 50,
              text_size: 40,
              char_space: 0,
              color: 0xFF00BB00,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 33,
              y: 49,
              w: 78,
              h: 50,
              text_size: 40,
              char_space: 0,
              color: 0xFFFF0006,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 309,
              y: 8,
              w: 68,
              h: 40,
              text_size: 25,
              char_space: 0,
              color: 0xFF1DD6FF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 255,
              y: 23,
              image_array: ["Bat_1.png","Bat_2.png","Bat_3.png","Bat_4.png","Bat_5.png","Bat_6.png","Bat_7.png","Bat_8.png","Bat_9.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 152,
              y: 62,
              w: 82,
              h: 50,
              text_size: 35,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 151,
              y: 17,
              w: 85,
              h: 50,
              text_size: 35,
              char_space: -2,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_string: .,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 114,
              hour_array: ["N_00.png","N_01.png","N_02.png","N_03.png","N_04.png","N_05.png","N_06.png","N_07.png","N_08.png","N_09.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 215,
              minute_startY: 114,
              minute_array: ["N_00.png","N_01.png","N_02.png","N_03.png","N_04.png","N_05.png","N_06.png","N_07.png","N_08.png","N_09.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180,
              y: 114,
              src: 'N_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'FonAOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 309,
              y: 8,
              w: 68,
              h: 40,
              text_size: 25,
              char_space: 0,
              color: 0xFF999999,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 255,
              y: 23,
              image_array: ["Bat_1.png","Bat_2.png","Bat_3.png","Bat_4.png","Bat_5.png","Bat_6.png","Bat_7.png","Bat_8.png","Bat_9.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 152,
              y: 61,
              w: 82,
              h: 50,
              text_size: 35,
              char_space: 0,
              color: 0xFF999999,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 151,
              y: 17,
              w: 85,
              h: 50,
              text_size: 35,
              char_space: -2,
              color: 0xFF999999,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_string: .,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 114,
              hour_array: ["N_00.png","N_01.png","N_02.png","N_03.png","N_04.png","N_05.png","N_06.png","N_07.png","N_08.png","N_09.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 215,
              minute_startY: 114,
              minute_array: ["N_00.png","N_01.png","N_02.png","N_03.png","N_04.png","N_05.png","N_06.png","N_07.png","N_08.png","N_09.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180,
              y: 114,
              src: 'N_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

const weatherImg = hmUI.createWidget(hmUI.widget.IMG, {
	x: 116,
	y: 287,
	w: 145,
	h: 100,
	src: 'w_25.png',
});

const tempText = hmUI.createWidget(hmUI.widget.TEXT, {
	x: 144,
	y: 396,
	w: 113,
	h: 50,
	text_size: 46,
	char_space: 0,
	line_space: 0,
//	font: 'fonts/SquadaOne-Regular.ttf',
	color: 0xFFFFFFFF,
	align_h: hmUI.align.CENTER_H,
	align_v: hmUI.align.CENTER_V,
//	unit_type: 1,
//	text_style: hmUI.text_style.ELLIPSIS,
//	type: tempWithSign(newData.temperature),
//	show_level: hmUI.show_level.ONLY_NORMAL,
});

const tempminwidget = hmUI.createWidget(hmUI.widget.TEXT, {
	x: 52,
	y: 305,
	w: 95,
	h: 40,
	text_size: 40,
	char_space: 0,
	line_space: 0,
//	font: 'fonts/SquadaOne-Regular.ttf',
	color: 0xFFFFFFFF,
	align_h: hmUI.align.CENTER_H,
	align_v: hmUI.align.CENTER_V,
});

const tempmaxwidget = hmUI.createWidget(hmUI.widget.TEXT, {
	x: 251,
	y: 305,
	w: 95,
	h: 40,
	text_size: 40,
	char_space: 0,
	line_space: 0,
//	font: 'fonts/SquadaOne-Regular.ttf',
	color: 0xFFFFFFFF,
	align_h: hmUI.align.CENTER_H,
	align_v: hmUI.align.CENTER_V,
});

cityNamewidget = hmUI.createWidget(hmUI.widget.TEXT, {
	x: 90,
	y: 268,
	w: 212,
	h: 30,
	text_size: 25,
	text: '--',
	color: 0xffffff,
	align_h: hmUI.align.CENTER_H,
	align_v: hmUI.align.CENTER_V
});

//buttonWidget = hmUI.createWidget(hmUI.widget.BUTTON, {
//	x: centerX + 20,
//	y: DEVICE_HEIGHT - 100,
//	w: 80,
//	h: 70,
//	text: '>',
//	text_size: 36,
//	normal_color: 0x222222,
//	press_color: 0x454545,
//	radius: 10,
//	click_func: () => {
//	weatherProvider.next();
//  }
//});

//	night_icons: [],				// индексы иконок для замены день-ночь
//	index: 0,					// текущий индекс провайдера (сохраняется и считывается из памяти)
//	show_toast: true,				// показывать всплывающее сообщение при переключении провайдера
//	temp_widget: null,				// виджет TEXT для отображения температуры
//	temp_max_widget: null,				// виджет TEXT для отображения максимальной температуры
//	temp_min_widget: null,				// виджет TEXT для отображения минимальной температуры
//	temp_feels_widget: null,			// виджет TEXT для отображения ощущаемой температуры
//	description_widget: null,			// виджет TEXT для отображения текстового описания текущей погоды
//	cityName_widget: null,				// виджет TEXT для отображения названия города
//	icon_widget: null,				// виджет IMG для отображения значка погоды
//	time_sensor: null,				// сенсор времени, если не задан, то создается новый
//	weather_sensor: null,				// сенсор погоды, если не задан, то создается новый
//	file_name: 'weather.json',			// имя файла с погодными данными
//	auto_update: true,				// автоматическое обновление погоды (нет необходимости добавлять weatherProvider.update() в event.MINUTEEND и WIDGET_DELEGATE)
//	lang: hmSetting.getLanguage() == 4 ? 0 : 1,	// языка устройства	(Русский = 0 / Английский = 1) - по умолчанию соответствует языку на устройстве пользователя




const weatherProvider = new WeatherProvider({
	index: 2,
	auto_update: true,
//	night_icons: [0, 1, 2, 3, 14],     // здесь список "ночных" значков погоды
	show_toast: false,                           // показывать всплывающее сообщение при переключении провайдера
	temp_widget: tempText,                  // имя виджета для отображения температуры
	temp_min_widget: tempminwidget,                  
	temp_max_widget: tempmaxwidget,                 
	icon_widget: weatherImg,               // имя виджета для отображения иконки
	cityName_widget: cityNamewidget,	// имя виджета для отображения названия города
});
            // end user_script_beforeShortcuts.js
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 36,
              y: 6,
              w: 100,
              h: 89,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 215,
              y: 108,
              w: 168,
              h: 164,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 11,
              y: 108,
              w: 159,
              h: 164,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_walking_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 16,
              y: 360,
              w: 118,
              h: 80,
              type: hmUI.data_type.WALKING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 118,
              y: 272,
              w: 163,
              h: 110,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Piks.png',
              normal_src: 'Piks.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1066654, url: 'page/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 269,
              y: 360,
              w: 113,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Piks.png',
              normal_src: 'Piks.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1078057, url: 'page/start_page' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 274,
              // y: 3,
              // w: 119,
              // h: 91,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'Piks.png',
              // normal_src: 'Piks.png',
              // bg_list: Fon|C_0|C_1|C_2|C_3|C_4|C_5|C_6,
              // toast_list: Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 274,
              y: 3,
              w: 119,
              h: 91,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Piks.png',
              normal_src: 'Piks.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '.' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '.' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('day/month font');
              if (updateHour) {
                let idle_DayStr = timeSensor.day.toString();
                let idle_MonthStr = timeSensor.month.toString();
                idle_DayStr = idle_DayStr.padStart(2, '0');
                idle_MonthStr = idle_MonthStr.padStart(2, '0');
                let idle_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  idle_DayMonthStr = idle_MonthStr + '.' + idle_DayStr;
                }
                if (dateFormat == 1) {
                  idle_DayMonthStr = idle_DayStr + '.' + idle_MonthStr;
                }
                idle_day_month_font.setProperty(hmUI.prop.TEXT, idle_DayMonthStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}